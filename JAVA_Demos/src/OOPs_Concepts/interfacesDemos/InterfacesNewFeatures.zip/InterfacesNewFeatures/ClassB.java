package OOPs_Concepts.interfacesDemos.InterfacesNewFeatures;

public class ClassB implements I1,I3 {

	 public static void main(String[] args) {
		I1.m1();
		I1.m3();
		
		I2.m2();
		I2.m3();
		
		I3.m4();
	}

}
